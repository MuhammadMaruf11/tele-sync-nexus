export const servicesData = [
    {
        id: "1",
        icon: 'fa-solid fa-megaphone fa-fw',
        title: 'Digital Marketing',
        description: `THIS IS NOT YOUR LOCAL IT CENTRE’S DIGITAL MARKETING SERVICE THIS IS NUCLEAR WARFARE FOR YOUR BRAND. GUARANTEED TO SMASH YOUR KPIS OR WE WORK FOR FREE!`,
        url: '',
    },
    {
        id: "2",
        icon: 'fa-solid fa-message-sms fa-fw',
        title: 'A2P SMS',
        description: `Elevate your worldwide communication capabilities with a platform designed to excel in terms of scalability, rapidity, and reliability!`,
        url: '',
    },
    {
        id: "3",
        icon: 'fa-sharp fa-solid fa-receipt fa-fw',
        title: 'Case Study',
        description: `Our case studies are going to raise your eyebrow and want to handle your business account.
                        Feel free to check our mind blowing results below and book a call with us.`,
        url: '',
    },
]